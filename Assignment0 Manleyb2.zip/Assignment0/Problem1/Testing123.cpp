//
//	Brian Manley					CPSC 200				
//	manleyb2@ferris.edu				Spring 2018
//									Assignment 0
//	FILE: Testing123.cpp			1/11/2018
//

//Oath of Originality: I, Brian Manley, pledge that the
//contents of this file are my own independent work and conform to
//all University policies on academic integrity.

// Testing the Visual C++ compiler

#include <iostream>
using namespace std;

void main()
{
	cout << "Testing 1, 2, 3." << endl;

	printf_s("Hello World \n");
	
	return;
}